// example_test_spec.js

// Import necessary Cypress commands
import { visitPage, checkElement } from './Supporting_Functions/supportingFunctions';

describe('Example Test Suite', () => {
  it('should visit the page and check element', () => {
    visitPage('https://example.com');
    checkElement('#example-element');
  });
});
