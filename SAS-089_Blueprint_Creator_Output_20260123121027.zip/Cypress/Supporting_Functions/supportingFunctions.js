// supportingFunctions.js

// Function to visit a page
export function visitPage(url) {
  cy.visit(url);
}

// Function to check if an element is visible
export function checkElement(selector) {
  cy.get(selector).should('be.visible');
}
