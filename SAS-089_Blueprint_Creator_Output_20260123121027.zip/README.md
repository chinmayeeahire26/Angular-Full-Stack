# Project Structure

This project contains the following structure based on the blueprint guidelines:

- Cypress
  - Starting Test Case
  - Supporting Functions
