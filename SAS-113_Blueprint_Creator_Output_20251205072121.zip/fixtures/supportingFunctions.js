module.exports = {
  login: function(username, password) {
    cy.get('#username').type(username);
    cy.get('#password').type(password);
    cy.get('#loginButton').click();
  },
  logout: function() {
    cy.get('#logoutButton').click();
  }
};
